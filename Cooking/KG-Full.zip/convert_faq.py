import pandas as pd
import json
import re
import uuid
import hashlib

# ==============================================================================
# 1. SETUP & CONFIGURATION
# ==============================================================================
INPUT_FILE = 'faq_viewer_export.csv'
OUTPUT_FILE = 'faq_data.json'

print(f"Loading {INPUT_FILE}...")
try:
    df = pd.read_csv(INPUT_FILE)
except FileNotFoundError:
    print(f"Error: {INPUT_FILE} not found. Make sure it is in the project root.")
    exit()

# ==============================================================================
# 2. ONTOLOGY HELPER FUNCTIONS
# ==============================================================================
def generate_id(prefix):
    return f"{prefix}_{str(uuid.uuid4())[:8]}"

def create_evidence(text, source_url):
    """
    Creates an EvidenceAnchor node as required by the ontology.
    """
    # Create deterministic ID based on text content to avoid duplicates
    text_hash = hashlib.md5(text.encode()).hexdigest()[:8]
    
    return {
        "id": f"EV_{text_hash}",
        "type": "EvidenceAnchor",
        "extracted_text": text,       # MUST be exact quote
        "source_url": source_url,
        "extraction_method": "rule_based"
    }

def identify_responsible_party(text):
    """
    Assigns a ResponsibleParty based on keywords.
    """
    text_lower = text.lower()
    
    if 'dealer' in text_lower or 'retailer' in text_lower:
        return 'RP_DEALER_O' # Originating Dealer
    if 'dmv' in text_lower or 'state' in text_lower:
        return 'RP_DMV'
    if 'call' in text_lower or 'contact us' in text_lower or 'phone' in text_lower:
        return 'RP_TFS_CC'   # Contact Center
    if 'mail' in text_lower:
        return 'RP_TFS_OPS'  # Operations/Mail
    if 'app' in text_lower or 'online' in text_lower or 'website' in text_lower:
        return 'RP_TFS_DIG'  # Digital Platform
    
    return 'RP_CUSTOMER'     # Default to Customer

def derive_leakage(step_id, is_offline, text, evidence_id):
    """
    Derives ValueLeakage nodes from process friction.
    """
    leakages = []
    
    # LOGIC: If step is offline, it causes TIME/EFFORT leakage
    if is_offline:
        leakages.append({
            "id": generate_id("VL"),
            "type": "ValueLeakage",
            "leakage_type": "TIME",
            "magnitude": "HIGH",
            "driver": f"Offline step required: {text[:30]}...",
            "step_ref": step_id,
            "evidence_ref": evidence_id
        })
        
    return leakages

def map_product(row):
    """
    Maps text to the 6 Core Products using weighted keywords.
    Eliminates PROD_GENERAL by forcing mapping to Core Financial products if ambiguous.
    """
    url = str(row['Source URL']).lower()
    question = str(row['Question']).lower()
    answer = str(row['Answer']).lower()
    text = f"{url} {question} {answer}"
    
    # 1. DEFINE WEIGHTED KEYWORDS
    # High score (10) = Unique feature
    # Low score (2) = Related concept
    keywords = {
        'PROD_LEASE': {
            'lease': 10, 'mileage': 8, 'wear': 5, 'residual': 8, 'turn-in': 10, 
            'inspection': 5, 'disposition': 10, 'lessor': 10
        },
        'PROD_RETAIL': {
            'finance': 5, 'retail': 10, 'loan': 8, 'apr': 5, 'interest': 5, 
            'principal': 8, 'lien': 8, 'title': 5, 'payoff': 8, 'simple interest': 10
        },
        'PROD_VSA': {
            'vsa': 10, 'vehicle service agreement': 10, 'mechanical': 5, 
            'breakdown': 5, 'deductible': 5, 'extended warranty': 5, 'protection plan': 2
        },
        'PROD_GAP': {
            'gap': 10, 'guaranteed auto': 10, 'total loss': 8, 'stolen': 5, 'insurance': 2
        },
        'PROD_EWU': {
            'ewu': 10, 'excess wear': 10, 'dent': 2, 'scratch': 2
        },
        'PROD_TWP': {
            'twp': 10, 'tire': 8, 'wheel': 8, 'hazard': 5, 'road': 2
        }
    }
    
    # 2. CALCULATE SCORES
    scores = {pid: 0 for pid in keywords}
    
    for pid, terms in keywords.items():
        for term, weight in terms.items():
            if term in text:
                scores[pid] += weight
                
    # 3. DETERMINE WINNERS
    # Filter out products with 0 score
    active_products = {k: v for k, v in scores.items() if v > 0}
    
    if not active_products:
        # FALLBACK: If strictly no keywords match, it's likely a general account question
        # (e.g. "Change Address", "Login"). These apply to the Core Financial products.
        return ['PROD_LEASE', 'PROD_RETAIL']
        
    # Find the max score
    max_score = max(active_products.values())
    
    # Return all products that are within 50% of the top score (handles overlap)
    # e.g., if Lease=20 and Retail=15, return both. If Lease=20 and GAP=2, return only Lease.
    threshold = max_score * 0.5
    final_products = [pid for pid, score in active_products.items() if score >= threshold]
    
    return final_products

def extract_latency(text, step_id, evidence_id):
    pattern = r'(\d+(?:-\d+)?)\s*(business\s+days?|days?|hours?|weeks?)'
    matches = re.findall(pattern, text, re.IGNORECASE)
    latencies = []
    for val, unit in matches:
        latencies.append({
            "id": generate_id("LAT"),
            "type": "LatencyWindow",
            "duration": val,
            "unit": unit.upper().replace(' ', '_'),
            "step_ref": step_id,
            "evidence_ref": evidence_id # Link to evidence
        })
    return latencies

def extract_escalation(text, step_id, evidence_id):
    pattern = r'(1-\d{3}-\d{3}-\d{4})'
    matches = re.findall(pattern, text)
    unique_paths = {} 
    
    for phone in matches:
        clean_number = phone.replace('-', '')
        entity_id = f"ESC_{clean_number}"
        unique_paths[phone] = {
            "id": entity_id, 
            "type": "EscalationPath",
            "contact_info": phone,
            "channel": "PHONE",
            "step_ref": step_id,
            "evidence_ref": evidence_id # Link to evidence
        }
    return list(unique_paths.values())

def classify_step(text):
    """
    Returns (action_type, verb, object) based on regex keywords.
    Schema compliance for 01_ONTOLOGY.md
    """
    text = text.lower()
    
    # 1. CONTACT / ESCALATION
    if any(x in text for x in ['call', 'dial', 'phone', 'contact', 'speak', 'representative']):
        return "CONTACT", "call", "support"
    
    # 2. DIGITAL ACTION (VIEW/SUBMIT)
    if any(x in text for x in ['click', 'visit', 'go to', 'log in', 'sign in', 'app', 'website']):
        return "VIEW", "visit", "portal"
        
    if any(x in text for x in ['submit', 'enter', 'fill', 'form', 'application']):
        return "SUBMIT", "submit", "form"
        
    if any(x in text for x in ['download', 'pdf', 'print']):
        return "DOWNLOAD", "download", "document"

    # 3. OFFLINE / MANUAL
    if any(x in text for x in ['mail', 'send', 'post', 'check']):
        return "SUBMIT", "mail", "documents"
        
    if any(x in text for x in ['visit dealer', 'retailer', 'dealership']):
        return "VISIT", "visit", "dealer"

    # 4. PASSIVE / WAIT
    if any(x in text for x in ['wait', 'allow', 'days', 'received']):
        return "WAIT", "wait for", "process"

    # Default
    return "VIEW", "review", "information"

def analyze_step(text, step_seq, path_id, source_url):
    text = text.strip()
    
    # --- NOISE FILTER ---
    # Fixes the "Yes" node problem. Drops tiny garbage sentences.
    if len(text) < 10: 
        return None 
        
    # 1. Create Evidence Anchor
    evidence = create_evidence(text, source_url)
    
    # 2. Determine Responsible Party & Offline Status
    party_id = identify_responsible_party(text)
    is_offline = party_id not in ['RP_TFS_DIG'] and 'online' not in text.lower() and 'app' not in text.lower()
    
    step_id = generate_id(f"STEP_{step_seq}")

    # 3. Classify Action (Strict Schema)
    action_type, verb, obj = classify_step(text)

    # 4. Create Step Node linked to PATH
    step = {
        "id": step_id,
        "type": "InstructionStep",
        "journey_path_ref": path_id,
        "sequence": step_seq,
        
        # SCHEMA COMPLIANCE FIXES:
        "instruction": text,       # Renamed from 'text' to 'instruction'
        "action_type": action_type, # NEW: Required Enum
        "verb": verb,               # NEW: Required String
        "object": obj,              # NEW: Required String
        
        "responsible_party_ref": party_id,
        "is_offline": is_offline,
        "is_manual": is_offline,    # simplified proxy
        "evidence_ref": evidence['id']
    }

    # 5. Check for Conditions
    condition = None
    if text.lower().startswith(('if ', 'unless ', 'note:', 'please note')):
        condition = {
            "id": generate_id("COND"),
            "type": "Condition",
            "trigger": text.split(',')[0] if ',' in text else text[:50],
            "consequence": "See instruction", # Placeholder
            "impact": "MEDIUM",               # Default
            "step_ref": step_id,
            "evidence_ref": evidence['id']
        }

    # 6. Derive Leakages
    leakages = derive_leakage(step_id, is_offline, text, evidence['id'])

    return {
        "step": step,
        "evidence": evidence,
        "has_condition": condition,
        "latencies": extract_latency(text, step_id, evidence['id']),
        "escalations": extract_escalation(text, step_id, evidence['id']),
        "leakages": leakages
    }

# ==============================================================================
# 3. MAIN PROCESSING
# ==============================================================================
# ==============================================================================
# 3. MAIN PROCESSING
# ==============================================================================

# 3a. DEFINE STATIC ENTITIES (Schema Compliant)
# These definitions now match 01_ONTOLOGY.md perfectly.

STATIC_PRODUCTS = {
    "PROD_LEASE": {
        "id": "PROD_LEASE",
        "name": "Vehicle Lease",
        "category": "FINANCING",
        "description": "Lease financing through Toyota Lease Trust",
        "complexity": "HIGH",
        "lifecycle_stages": ["ORIGINATION", "USAGE", "RENEWAL_EXIT"],
        "support_phone": "1-800-874-8822",
        "source_url": "toyotafinancial.com/us/en/financing_options/lease.html"
    },
    "PROD_RETAIL": {
        "id": "PROD_RETAIL",
        "name": "Retail Finance",
        "category": "FINANCING",
        "description": "Traditional vehicle financing",
        "complexity": "MEDIUM",
        "lifecycle_stages": ["ORIGINATION", "USAGE", "PAYOFF"],
        "support_phone": "1-800-874-8822",
        "source_url": "toyotafinancial.com/us/en/financing_options/retail.html"
    },
    "PROD_VSA": {
        "id": "PROD_VSA",
        "name": "Vehicle Service Agreement",
        "category": "PROTECTION",
        "description": "Extended protection plans",
        "complexity": "MEDIUM",
        "lifecycle_stages": ["USAGE", "CLAIMS"],
        "support_phone": "1-800-228-8559",
        "source_url": "toyotafinancial.com/us/en/vehicle_protection/vsa.html"
    },
    "PROD_GAP": {
        "id": "PROD_GAP",
        "name": "Guaranteed Auto Protection",
        "category": "PROTECTION",
        "description": "Total loss protection",
        "complexity": "LOW",
        "lifecycle_stages": ["USAGE", "CLAIMS"],
        "support_phone": "1-800-255-8713",
        "source_url": "toyotafinancial.com/us/en/vehicle_protection/gap.html"
    },
    "PROD_EWU": {
        "id": "PROD_EWU",
        "name": "Excess Wear & Use",
        "category": "PROTECTION",
        "description": "Lease-end wear protection",
        "complexity": "LOW",
        "lifecycle_stages": ["RENEWAL_EXIT"],
        "support_phone": "1-800-874-8822",
        "source_url": "toyotafinancial.com/us/en/vehicle_protection/ewu.html"
    },
    "PROD_TWP": {
        "id": "PROD_TWP",
        "name": "Tire & Wheel Protection",
        "category": "PROTECTION",
        "description": "Road hazard protection",
        "complexity": "LOW",
        "lifecycle_stages": ["USAGE", "CLAIMS"],
        "support_phone": "1-800-228-8559",
        "source_url": "toyotafinancial.com/us/en/vehicle_protection/twp.html"
    }
}

STATIC_CHANNELS = [
    {
        "id": "CH_WEB",
        "type": "WEB",
        "name": "TFS Web Portal",
        "contact": "toyotafinancial.com",
        "is_offline": False,
        "is_self_service": True,
        "availability": "24/7",
        "products": ["ALL"]
    },
    {
        "id": "CH_MOBILE",
        "type": "MOBILE",
        "name": "MyTFS Mobile App",
        "contact": "App Store/Play",
        "is_offline": False,
        "is_self_service": True,
        "availability": "24/7",
        "products": ["PROD_LEASE", "PROD_RETAIL"]
    },
    {
        "id": "CH_PHONE_MAIN",
        "type": "PHONE",
        "name": "Customer Service",
        "contact": "1-800-874-8822",
        "is_offline": True,
        "is_self_service": False,
        "availability": "Mon-Fri 8am-5pm Local",
        "products": ["PROD_LEASE", "PROD_RETAIL"]
    }
]

STATIC_RESPONSIBLE_PARTIES = [
    {
        "id": "RP_CUSTOMER",
        "name": "Customer",
        "type": "CUSTOMER",
        "role": "Primary actor",
        "controllability": "HIGH",
        "is_human": True
    },
    {
        "id": "RP_TFS_CC",
        "name": "TFS Contact Center",
        "type": "INTERNAL",
        "role": "Phone support agent",
        "controllability": "HIGH",
        "is_human": True
    },
    {
        "id": "RP_DEALER_O",
        "name": "Originating Dealer",
        "type": "EXTERNAL",
        "role": "Vehicle return location",
        "controllability": "MEDIUM",
        "is_human": True
    },
    {
        "id": "RP_TFS_DIG",
        "name": "TFS Digital Platform",
        "type": "INTERNAL",
        "role": "Web/Mobile Interface",
        "controllability": "HIGH",
        "is_human": False
    },
    {
        "id": "RP_DMV",
        "name": "State DMV",
        "type": "EXTERNAL",
        "role": "Regulatory Body",
        "controllability": "LOW",
        "is_human": True
    },
    {
        "id": "RP_TFS_OPS",
        "name": "TFS Operations",
        "type": "INTERNAL",
        "role": "Back-office processing",
        "controllability": "HIGH",
        "is_human": True
    }
]

# 3b. INITIALIZE GRAPH
knowledge_graph = {
    "products": STATIC_PRODUCTS,
    "channels": STATIC_CHANNELS,            # Added
    "responsible_parties": STATIC_RESPONSIBLE_PARTIES, # Added
    "intents": {},
    "journey_paths": [],
    "steps": [],
    "conditions": [],
    "latencies": [],
    "escalations": [],
    "evidence_anchors": [],
    "value_leakages": [],
    "content_assets": []                    # Added placeholder for next task
}

print("Parsing FAQs...")

unique_assets = {}

for index, row in df.iterrows():
    intent_id = f"INT_{row['ID']}"
    product_refs = map_product(row)
    source_url = str(row['Source URL']).strip()
    
    # NEW: ContentAsset Extraction
    # Check if we've already created an asset for this URL to avoid duplicates
    asset_id = f"CA_{hashlib.md5(source_url.encode()).hexdigest()[:8]}"
    
    # We use a set or dictionary to track unique assets outside the loop.
    # IMPORTANT: Initialize 'unique_assets = {}' before the loop starts!
    
    if source_url and asset_id not in unique_assets:
        unique_assets[asset_id] = {
            "id": asset_id,
            "type": "ContentAsset",
            "url": source_url,
            "title": f"Source: {row['Question'][:30]}...", # Placeholder title from context
            "format": "WEB_PAGE",
            "products": product_refs, # Asset belongs to these products
            "last_crawled": "2025-01-21T00:00:00Z", # Mock timestamp
            "content_hash": f"sha256:{hashlib.sha256(source_url.encode()).hexdigest()[:10]}"
        }

    # 1. CustomerIntent (Updated)
    knowledge_graph['intents'][intent_id] = {
        "id": intent_id,
        "name": str(row['Question']).strip(),
        "product_refs": product_refs, 
        "type": "CustomerIntent",
        "asset_refs": [asset_id] if source_url else [] # NEW: Link Intent -> Asset
    }
    
    # 2. JourneyPath (NEW LAYER)
    # Every intent gets a primary path to hold steps
    path_id = f"PATH_{row['ID']}_PRI"
    knowledge_graph['journey_paths'].append({
        "id": path_id,
        "type": "JourneyPath",
        "path_type": "PRIMARY",
        "intent_ref": intent_id,
        "name": "Standard Process",
        "product_ref": product_refs[0] if product_refs else "PROD_GENERAL"
    })

    # 3. InstructionSteps
    raw_answer = str(row['Answer']).replace('e.g.', 'eg') 
    sentences = re.split(r'(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?)\s', raw_answer)
    
    seq_counter = 1
    for sentence in sentences:
        # Pass path_id instead of intent_id
        result = analyze_step(sentence, seq_counter, path_id, source_url)
        
        if result:
            # Store all extracted entities
            knowledge_graph['steps'].append(result['step'])
            knowledge_graph['evidence_anchors'].append(result['evidence'])
            
            if result['has_condition']:
                knowledge_graph['conditions'].append(result['has_condition'])
                
            knowledge_graph['latencies'].extend(result['latencies'])
            knowledge_graph['escalations'].extend(result['escalations'])
            knowledge_graph['value_leakages'].extend(result['leakages'])
            
            seq_counter += 1

knowledge_graph['content_assets'] = list(unique_assets.values())

# Export
with open(OUTPUT_FILE, 'w') as f:
    json.dump(knowledge_graph, f, indent=2)

print(f"✅ Generated {OUTPUT_FILE}")
print(f"   - Intents: {len(knowledge_graph['intents'])}")
print(f"   - Paths: {len(knowledge_graph['journey_paths'])}")
print(f"   - Steps: {len(knowledge_graph['steps'])}")
print(f"   - Evidence: {len(knowledge_graph['evidence_anchors'])}")
print(f"   - Leakages: {len(knowledge_graph['value_leakages'])}")