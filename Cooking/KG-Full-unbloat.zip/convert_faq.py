import pandas as pd
import json
import re
import uuid

# ==============================================================================
# 1. SETUP & CONFIGURATION
# ==============================================================================
INPUT_FILE = 'faq_viewer_export.csv'
OUTPUT_FILE = 'faq_data.json'

print(f"Loading {INPUT_FILE}...")
try:
    df = pd.read_csv(INPUT_FILE)
except FileNotFoundError:
    print(f"Error: {INPUT_FILE} not found. Make sure it is in the project root.")
    exit()

# ==============================================================================
# 2. ONTOLOGY HELPER FUNCTIONS
# ==============================================================================
def generate_id(prefix):
    return f"{prefix}_{str(uuid.uuid4())[:8]}"

def map_product(row):
    """
    Maps a CSV row to products based on comprehensive keyword matching
    across URL, Question, and Answer.
    """
    # 1. Combine all sources into one searchable blob
    url = str(row['Source URL']).lower()
    question = str(row['Question']).lower()
    answer = str(row['Answer']).lower()
    
    # "search_text" is what we will check against
    search_text = f"{url} {question} {answer}"
    
    products = []
    
    # --- RULE 1: LEASE (The most specific keyword) ---
    if 'lease' in search_text: 
        products.append('PROD_LEASE')

    # --- RULE 2: RETAIL / FINANCE ---
    # We look for 'finance', 'loan', 'apr', 'principal'
    if any(x in search_text for x in ['finance', 'loan', 'retail', 'apr', 'principal']): 
        products.append('PROD_RETAIL')

    # --- RULE 3: VSA (Protection) ---
    # Look for 'vsa', 'vehicle service', 'mechanical breakdown'
    if 'vsa' in search_text or 'vehicle service agreement' in search_text or 'mechanical breakdown' in search_text:
        products.append('PROD_VSA')

    # --- RULE 4: GAP (Protection) ---
    if 'gap' in search_text or 'total loss' in search_text or 'guaranteed auto' in search_text:
        products.append('PROD_GAP')
        
    # --- RULE 5: TIRE & WHEEL ---
    if ('tire' in search_text or 'wheel' in search_text) and 'protection' in search_text:
        products.append('PROD_TWP')
        
    # --- RULE 6: EXCESS WEAR ---
    if 'wear' in search_text and 'use' in search_text:
        products.append('PROD_EWU')

    # --- DEFAULT: GENERAL INQUIRIES ---
    # If no specific product keywords were found, this is likely a platform question
    # (e.g., "How do I log in?", "What is the mailing address?")
    if not products: 
        products.append('PROD_GENERAL')
        
    return list(set(products))

def extract_latency(text):
    # Extracts "2-3 business days", etc.
    pattern = r'(\d+(?:-\d+)?)\s*(business\s+days?|days?|hours?|weeks?)'
    matches = re.findall(pattern, text, re.IGNORECASE)
    latencies = []
    for val, unit in matches:
        latencies.append({
            "id": generate_id("LAT"),
            "type": "LatencyWindow",
            "duration": val,
            "unit": unit.upper().replace(' ', '_'),
            "source_text": f"{val} {unit}"
        })
    return latencies

def extract_escalation(text):
    # Extracts 1-800 phone numbers
    pattern = r'(1-\d{3}-\d{3}-\d{4})'
    matches = re.findall(pattern, text)
    
    # Use a dictionary to automatically handle duplicates based on the phone number
    unique_paths = {} 
    
    for phone in matches:
        # CLEANUP: Remove dashes to make a clean ID
        clean_number = phone.replace('-', '')
        
        # DETERMINISTIC ID: Based on the number, not a random UUID
        # Now, every time we see this number, we get the SAME ID.
        entity_id = f"ESC_{clean_number}"
        
        unique_paths[phone] = {
            "id": entity_id, 
            "type": "EscalationPath",
            "contact_info": phone,
            "channel": "PHONE"
        }
    
    # Return the values (this automatically removes duplicates for this text)
    return list(unique_paths.values())

def analyze_step(text, step_seq, intent_id):
    text = text.strip()
    if not text: return None
    
    # Check for Conditions (Entity #7)
    condition = None
    if text.lower().startswith(('if ', 'unless ', 'note:', 'please note')):
        condition = {
            "id": generate_id("COND"),
            "type": "Condition",
            "trigger": text.split(',')[0] if ',' in text else text[:50],
            "text": text
        }

    return {
        "id": generate_id(f"STEP_{step_seq}"),
        "type": "InstructionStep",
        "intent_ref": intent_id,
        "sequence": step_seq,
        "text": text,
        "has_condition": condition,
        "latencies": extract_latency(text),
        "escalations": extract_escalation(text)
    }

# ==============================================================================
# 3. MAIN PROCESSING
# ==============================================================================
knowledge_graph = {
    "products": {
        "PROD_LEASE": {"id": "PROD_LEASE", "name": "Vehicle Lease"},
        "PROD_RETAIL": {"id": "PROD_RETAIL", "name": "Retail Finance"},
        "PROD_VSA": {"id": "PROD_VSA", "name": "Vehicle Service Agreement"},
        "PROD_GAP": {"id": "PROD_GAP", "name": "Guaranteed Auto Protection"},
        "PROD_EWU": {"id": "PROD_EWU", "name": "Excess Wear & Use Protection"},
        "PROD_TWP": {"id": "PROD_TWP", "name": "Tire & Wheel Protection"},
        "PROD_GENERAL": {"id": "PROD_GENERAL", "name": "General Inquiries"}
    },
    "intents": {},
    "steps": [],
    "conditions": [],
    "latencies": [],
    "escalations": []
}

print("Parsing FAQs...")

for index, row in df.iterrows():
    intent_id = f"INT_{row['ID']}"
    
    # 1. CustomerIntent
    # UPDATED: Pass the whole 'row' to map_product, not just the URL
    knowledge_graph['intents'][intent_id] = {
        "id": intent_id,
        "name": str(row['Question']).strip(),
        "product_refs": map_product(row), 
        "type": "CustomerIntent"
    }
    
    # 2. InstructionSteps
    # Split by periods that look like end of sentences
    raw_answer = str(row['Answer']).replace('e.g.', 'eg') 
    sentences = re.split(r'(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?)\s', raw_answer)
    
    seq_counter = 1
    for sentence in sentences:
        step_obj = analyze_step(sentence, seq_counter, intent_id)
        if step_obj:
            # Flatten the hierarchy for the graph
            if step_obj['has_condition']:
                knowledge_graph['conditions'].append({**step_obj['has_condition'], "step_ref": step_obj['id']})
                
            for lat in step_obj['latencies']:
                knowledge_graph['latencies'].append({**lat, "step_ref": step_obj['id']})

            for esc in step_obj['escalations']:
                knowledge_graph['escalations'].append({**esc, "step_ref": step_obj['id']})

            # Clean up the step object before saving
            del step_obj['has_condition']
            del step_obj['latencies']
            del step_obj['escalations']
            
            knowledge_graph['steps'].append(step_obj)
            seq_counter += 1

# Export
with open(OUTPUT_FILE, 'w') as f:
    json.dump(knowledge_graph, f, indent=2)

print(f"✅ Generated {OUTPUT_FILE}")
print(f"   - Intents: {len(knowledge_graph['intents'])}")
print(f"   - Conditions: {len(knowledge_graph['conditions'])}")